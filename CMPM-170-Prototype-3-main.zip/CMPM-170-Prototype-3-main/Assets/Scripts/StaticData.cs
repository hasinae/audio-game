using UnityEngine;

public class StaticData
{
    public static int FinalPoints;
}
